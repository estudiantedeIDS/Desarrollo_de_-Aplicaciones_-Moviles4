var aux: String = ""
var opcionIngresada: String = aux
var saldoTotal: Double = 0

func deposito(){         // Declaración de la funcion deposito
print("Ingrese la cantidad a Depósitar")
print("\n")
aux = readLine()!
opcionIngresada = aux
  
let cantidadDepositada = Double(opcionIngresada)!  // Creando la variable double para sumarla al saldo total
print("\n")
print("Abono depositado exitosamente por $ \(cantidadDepositada) pesos")
saldoTotal = saldoTotal + cantidadDepositada       //Actualización del saldo total
print("\n")
print("Tu saldo actual es: $ \(saldoTotal) pesos")
print("\n")
}    // cierre función deposito

while opcionIngresada != "4" {     // Inicio Ciclo while para que se repita el menú
print(" *****  Bienvenidos a Banco Mexicano *****")
print("      ***   Banca en linea   ***       ")
print("\n")
print("1.- Depósito")
print("2.- Retiro")
print("3.- Saldo")
print("4.- Salir")
print("\n")
print("Eliga una opción por favor...")

aux = readLine()!         // lectura de la 
opcionIngresada = aux     // opción ingresada

switch opcionIngresada{    //Inicio ciclo switch 1
  case "1":
   deposito()
   print("\n")  
   print(" Deseas realizar otro Depósito? s/S n/N")
     aux = readLine()!  
     opcionIngresada = aux
     switch opcionIngresada {    // Inicio Switch  2
        case "s", "S", "Si", "sI","SI","si":
        deposito()

        case "n", "N", "No", "nO", "NO", "no":
        print("Desea continuar con otra operación? (S/N)")
            aux = readLine()!  
            opcionIngresada = aux
               
         if(opcionIngresada == "N") || (opcionIngresada == "NO") || (opcionIngresada == "no") || (opcionIngresada == "n") {
           print("Gracias por su visita, vuelva pronto !!!")
           print("\n")
           }  // cierre if
       
        default:
        print(" ¡Opción no válidA!")
        }  // cierre  switch 2
  
    case "4":
    print("\n")
    print("Gracias por su visita, vuelva pronto !!!")
    default:
    print("\n")
    print(" ¡ Opción no válida !")
    print("\n")
  
    }   //cierre ciclo switch 1
  }   // cierre ciclo while